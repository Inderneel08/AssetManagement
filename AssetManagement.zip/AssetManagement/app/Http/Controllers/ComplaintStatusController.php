<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ComplaintStatusController extends Controller
{
    //

    // public function showComplaintStatus()
    // {
    //     $issuesResolved = DB::table('issues')->where('status','=',0)->get();

    //     $issuesPending = DB::table('issues')->where('status','!=',0)->get();

    //     $issueResolvedCount = count($issuesResolved);

    //     $issuesPendingCount = count($issuesPending);


    // }


}
